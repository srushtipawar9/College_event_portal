
import sqlite3

conn = sqlite3.connect('events.db')
c = conn.cursor()

# Table for events
c.execute('''
    CREATE TABLE IF NOT EXISTS events (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        title TEXT NOT NULL,
        description TEXT,
        date TEXT NOT NULL,
        time TEXT NOT NULL
    )
''')

# Table for student registrations
c.execute('''
    CREATE TABLE IF NOT EXISTS registrations (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        student_name TEXT NOT NULL,
        email TEXT NOT NULL,
        department TEXT,
        event_id INTEGER,
        FOREIGN KEY(event_id) REFERENCES events(id)
    )
''')

conn.commit()
conn.close()

print("✅ Database created: events.db")
