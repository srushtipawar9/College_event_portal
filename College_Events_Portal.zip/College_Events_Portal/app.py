from flask import Flask, render_template, request, redirect, session

import sqlite3
import smtplib
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart

app = Flask(__name__)
app.secret_key = 'your_secret_key_here'

@app.route('/')
def home():
    return render_template('index.html')


@app.route('/admin/login', methods=['GET', 'POST'])
def admin_login():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']

        if username == 'admin' and password == 'admin123':  # 👈 change if needed
            session['admin_logged_in'] = True
            return redirect('/admin/dashboard')
        else:
            return "<h3>❌ Invalid credentials</h3><a href='/admin/login'>Try again</a>"

    return render_template('admin-login.html')

@app.route('/admin/dashboard')
def admin_dashboard():
    if not session.get('admin_logged_in'):
        return redirect('/admin/login')

    conn = sqlite3.connect('events.db')
    c = conn.cursor()
    c.execute("SELECT * FROM events")
    events = c.fetchall()
    conn.close()

    return render_template('admin-dashboard.html', events=events)

# 📧 Email confirmation function
def send_confirmation_email(to_email, student_name, event_title):
    sender_email = "srushtipawar455@gmail.com"
    sender_password = "lapt mybi skhr qoyf"  # Use App Password from Google

    message = MIMEMultipart("alternative")
    message["Subject"] = f"Confirmation: Registered for {event_title}"
    message["From"] = sender_email
    message["To"] = to_email

    html_content = f"""
    <html>
        <body>
            <p>Hi {student_name},<br>
            You have successfully registered for <strong>{event_title}</strong>.<br>
            Thanks!<br>
            College Events Portal
            </p>
        </body>
    </html>
    """
    message.attach(MIMEText(html_content, "html"))

    try:
        server = smtplib.SMTP_SSL("smtp.gmail.com", 465)
        server.login(sender_email, sender_password)
        server.sendmail(sender_email, to_email, message.as_string())
        server.quit()
        print("✅ Email sent to", to_email)
    except Exception as e:
        print("❌ Email sending failed:", e)

# ---------------- Admin Routes ---------------- #

@app.route('/admin/events/add', methods=['GET', 'POST'])
def add_event():
    if not session.get('admin_logged_in'):
        return redirect('/admin/login')

    if request.method == 'POST':
        title = request.form['title']
        description = request.form['description']
        date = request.form['date']
        time = request.form['time']

        conn = sqlite3.connect('events.db')
        c = conn.cursor()
        c.execute("INSERT INTO events (title, description, date, time) VALUES (?, ?, ?, ?)",
                  (title, description, date, time))
        conn.commit()
        conn.close()

        return redirect('/admin/dashboard')
    
    return render_template('add-event.html') 
   # previously: return redirect('/admin/dashboard')

@app.route('/admin/events/edit/<int:event_id>', methods=['GET', 'POST'])
def edit_event(event_id):
    if not session.get('admin_logged_in'):
        return redirect('/admin/login')

    conn = sqlite3.connect('events.db')
    c = conn.cursor()

    if request.method == 'POST':
        title = request.form['title']
        description = request.form['description']
        date = request.form['date']
        time = request.form['time']

        c.execute("UPDATE events SET title=?, description=?, date=?, time=? WHERE id=?",
                  (title, description, date, time, event_id))
        conn.commit()
        conn.close()
        return redirect('/admin/dashboard')

    c.execute("SELECT * FROM events WHERE id=?", (event_id,))
    event = c.fetchone()
    conn.close()

    return redirect('/')   # previously: return redirect('/admin/dashboard')

@app.route('/admin/events/delete/<int:event_id>')
def delete_event(event_id):
    if not session.get('admin_logged_in'):
        return redirect('/admin/login')

    conn = sqlite3.connect('events.db')
    c = conn.cursor()
    c.execute("DELETE FROM events WHERE id=?", (event_id,))
    conn.commit()
    conn.close()

    return redirect('/')   # previously: return redirect('/admin/dashboard')


@app.route('/admin/events/<int:event_id>/registrations')
def view_registrations(event_id):
    if not session.get('admin_logged_in'):
        return redirect('/admin/login')

    conn = sqlite3.connect('events.db')
    c = conn.cursor()

    c.execute("SELECT * FROM events WHERE id=?", (event_id,))
    event = c.fetchone()

    c.execute("SELECT * FROM registrations WHERE event_id=?", (event_id,))
    registrations = c.fetchall()
    conn.close()

    return render_template('view-registrations.html', event=event, registrations=registrations)

# ---------------- Public Student Routes ---------------- #

@app.route('/events')
def view_events():
    conn = sqlite3.connect('events.db')
    c = conn.cursor()
    c.execute("SELECT * FROM events")
    events = c.fetchall()
    conn.close()
    return render_template('events.html', events=events)

@app.route('/events/<int:event_id>/register', methods=['GET', 'POST'])
def register_event(event_id):
    conn = sqlite3.connect('events.db')
    c = conn.cursor()

    # Get event details
    c.execute("SELECT * FROM events WHERE id=?", (event_id,))
    event = c.fetchone()

    if request.method == 'POST':
        name = request.form['student_name']
        email = request.form['email']
        dept = request.form['department']

        c.execute("INSERT INTO registrations (student_name, email, department, event_id) VALUES (?, ?, ?, ?)",
                  (name, email, dept, event_id))
        conn.commit()
        conn.close()

        # ✅ Send confirmation email
        send_confirmation_email(email, name, event[1])

        return render_template('registration-success.html', student_name=name, event_title=event[1])



    conn.close()
    return render_template('register.html', event=event)

if __name__ == "__main__":
    app.run(debug=True)
